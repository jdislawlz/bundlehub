<?php
header('Location: ../admin_inventory.php');
?>