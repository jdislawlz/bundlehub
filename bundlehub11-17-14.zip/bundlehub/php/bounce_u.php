<?php
header('Location: ../admin_user.php');
?>